import TopPerformerCard from "./TopPerformerCard";

function TopPerfomancePage() {
  return (
    <div className="p-6">
      <TopPerformerCard />
    </div>
  );
}
export default TopPerfomancePage;